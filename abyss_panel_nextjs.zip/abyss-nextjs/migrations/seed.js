require('dotenv').config({ path: '.env.local' });
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME || 'abyss_panel',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'your_password',
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

async function seed() {
  const client = await pool.connect();
  try {
    console.log('🌱 Seeding database...');

    const username = process.env.ADMIN_USERNAME || 'admin';
    const password = process.env.ADMIN_PASSWORD || 'admin123';
    const email = process.env.ADMIN_EMAIL || 'admin@abyss.com';

    const existing = await client.query('SELECT id FROM users WHERE username = $1', [username]);
    if (existing.rows.length > 0) {
      console.log('ℹ️  Admin user already exists, skipping seed.');
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    await client.query(
      'INSERT INTO users (username, password, email, name, role) VALUES ($1, $2, $3, $4, $5)',
      [username, hashedPassword, email, 'Super Admin', 'superadmin']
    );

    console.log(`✅ Admin user created: ${username} / ${password}`);
    console.log('⚠️  Change the password immediately after first login!');
  } catch (err) {
    console.error('❌ Seed failed:', err.message);
    process.exit(1);
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
