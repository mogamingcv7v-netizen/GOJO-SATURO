import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// PUT /api/targets/:user_id/:type
export const PUT = withAuth(async (request, { params }) => {
  try {
    const { user_id, type } = params;
    const { value } = await request.json().catch(() => ({}));

    if (!['daily', 'monthly'].includes(type)) {
      return NextResponse.json({ error: 'Invalid target type' }, { status: 400 });
    }

    const result = await db.query(
      `INSERT INTO targets (user_id, type, value)
       VALUES ($1, $2, $3)
       ON CONFLICT (user_id, type)
       DO UPDATE SET value = EXCLUDED.value
       RETURNING *`,
      [user_id, type, value]
    );

    return NextResponse.json(result.rows[0]);
  } catch (err) {
    console.error('Update target error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
