import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/targets/:user_id
export const GET = withAuth(async (request, { params }) => {
  try {
    const { user_id } = params;
    const result = await db.query('SELECT * FROM targets WHERE user_id = $1', [user_id]);
    return NextResponse.json({ data: result.rows });
  } catch (err) {
    console.error('Get targets error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
