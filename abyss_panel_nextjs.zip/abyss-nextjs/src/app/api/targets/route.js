import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/targets
export const GET = withAuth(async () => {
  try {
    const result = await db.query('SELECT * FROM targets');
    return NextResponse.json({ data: result.rows });
  } catch (err) {
    console.error('Get targets error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
