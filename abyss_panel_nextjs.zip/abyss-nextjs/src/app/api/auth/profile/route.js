import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// PUT /api/auth/profile
export const PUT = withAuth(async (request) => {
  try {
    const { name, email, country } = await request.json().catch(() => ({}));

    const result = await db.query(
      'UPDATE users SET name = $1, email = $2, country = $3 WHERE id = $4 RETURNING id, username, name, email, country, role',
      [name || null, email || null, country || null, request.authUser.id]
    );

    return NextResponse.json(result.rows[0]);
  } catch (err) {
    console.error('Profile update error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
});
