import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import { signToken } from '@/lib/auth';
import { validateLogin } from '@/lib/validation';
import { checkRateLimit, getIp } from '@/lib/rateLimit';

export async function POST(request) {
  // Rate limit
  const { limited } = checkRateLimit(getIp(request));
  if (limited) {
    return NextResponse.json({ error: 'Too many requests, please try again later.' }, { status: 429 });
  }

  const body = await request.json().catch(() => ({}));

  const validationError = validateLogin(body);
  if (validationError) {
    return NextResponse.json(validationError, { status: 400 });
  }

  const { username, password } = body;

  try {
    const result = await db.query('SELECT * FROM users WHERE username = $1', [username]);

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Invalid username or password' }, { status: 401 });
    }

    const user = result.rows[0];

    if (!user.active) {
      return NextResponse.json({ error: 'Account is disabled' }, { status: 403 });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return NextResponse.json({ error: 'Invalid username or password' }, { status: 401 });
    }

    await db.query('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = $1', [user.id]);

    const token = signToken({ id: user.id, username: user.username, role: user.role });

    return NextResponse.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        country: user.country,
        role: user.role,
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
