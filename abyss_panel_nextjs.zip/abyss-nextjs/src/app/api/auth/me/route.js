import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';

// GET /api/auth/me
export const GET = withAuth(async (request) => {
  return NextResponse.json(request.authUser);
});
