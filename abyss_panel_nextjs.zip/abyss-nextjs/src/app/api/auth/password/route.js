import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// PUT /api/auth/password
export const PUT = withAuth(async (request) => {
  try {
    const { current_password, new_password } = await request.json().catch(() => ({}));

    if (!current_password || !new_password) {
      return NextResponse.json({ error: 'Current and new passwords are required' }, { status: 400 });
    }

    const result = await db.query('SELECT password FROM users WHERE id = $1', [request.authUser.id]);
    const user = result.rows[0];

    const isMatch = await bcrypt.compare(current_password, user.password);
    if (!isMatch) {
      return NextResponse.json({ error: 'Incorrect current password' }, { status: 401 });
    }

    const hashedPassword = await bcrypt.hash(new_password, 12);
    await db.query('UPDATE users SET password = $1 WHERE id = $2', [hashedPassword, request.authUser.id]);

    return NextResponse.json({ message: 'Password updated successfully' });
  } catch (err) {
    console.error('Password change error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
});
