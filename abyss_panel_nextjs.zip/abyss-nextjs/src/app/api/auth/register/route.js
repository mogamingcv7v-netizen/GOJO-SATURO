import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';
import { signToken } from '@/lib/auth';
import { validateRegister } from '@/lib/validation';
import { checkRateLimit, getIp } from '@/lib/rateLimit';

export async function POST(request) {
  const { limited } = checkRateLimit(getIp(request));
  if (limited) {
    return NextResponse.json({ error: 'Too many requests, please try again later.' }, { status: 429 });
  }

  const body = await request.json().catch(() => ({}));

  const validationError = validateRegister(body);
  if (validationError) {
    return NextResponse.json(validationError, { status: 400 });
  }

  const { username, password, name, email, country, dev_code } = body;

  try {
    // Check if user exists
    const checkUser = await db.query('SELECT id FROM users WHERE username = $1', [username.trim()]);
    if (checkUser.rows.length > 0) {
      return NextResponse.json({ error: 'Username already taken' }, { status: 400 });
    }

    let role = 'user';
    let code_id = null;

    if (dev_code) {
      const checkCode = await db.query(
        'SELECT id FROM dev_codes WHERE code = $1 AND used = false',
        [dev_code.trim()]
      );
      if (checkCode.rows.length === 0) {
        return NextResponse.json({ error: 'Invalid or already used developer code' }, { status: 400 });
      }
      role = 'dev';
      code_id = checkCode.rows[0].id;
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const result = await db.query(
      'INSERT INTO users (username, password, name, email, country, role) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id, username, name, email, country, role',
      [username.trim(), hashedPassword, name || null, email || null, country || null, role]
    );

    const newUser = result.rows[0];

    if (code_id) {
      await db.query(
        'UPDATE dev_codes SET used = true, used_by = $1, used_at = CURRENT_TIMESTAMP WHERE id = $2',
        [newUser.id, code_id]
      );
    }

    const token = signToken({ id: newUser.id, username: newUser.username, role: newUser.role });

    return NextResponse.json({ token, user: newUser }, { status: 201 });
  } catch (err) {
    console.error('Register error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
