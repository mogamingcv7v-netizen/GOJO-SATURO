import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// DELETE /api/admin/dev-codes/:id
export const DELETE = withAuth(async (request, { params }) => {
  try {
    const { id } = params;
    await db.query('DELETE FROM dev_codes WHERE id = $1', [id]);
    return NextResponse.json({ message: 'Code deleted' });
  } catch (err) {
    console.error('Delete dev code error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin']);
