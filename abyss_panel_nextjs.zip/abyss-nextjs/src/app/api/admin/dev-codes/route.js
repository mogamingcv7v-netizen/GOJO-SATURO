import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';
import { v4 as uuidv4 } from 'uuid';

// GET /api/admin/dev-codes
export const GET = withAuth(async () => {
  try {
    const result = await db.query('SELECT * FROM dev_codes ORDER BY created_at DESC');
    return NextResponse.json({ data: result.rows });
  } catch (err) {
    console.error('Get dev codes error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin']);

// POST /api/admin/dev-codes
export const POST = withAuth(async (request) => {
  try {
    const code = `DEV-${uuidv4().substring(0, 8).toUpperCase()}`;
    const result = await db.query(
      'INSERT INTO dev_codes (code, created_by) VALUES ($1, $2) RETURNING *',
      [code, request.authUser.id]
    );
    return NextResponse.json(result.rows[0], { status: 201 });
  } catch (err) {
    console.error('Generate dev code error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin']);
