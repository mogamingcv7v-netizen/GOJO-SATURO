import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';
import os from 'os';

// GET /api/admin/system-info
export const GET = withAuth(async () => {
  try {
    const userCount = await db.query('SELECT COUNT(*) FROM users');
    const numberCount = await db.query('SELECT COUNT(*) FROM numbers');
    const dbVersion = await db.query('SELECT version()');

    const formatMemory = (bytes) => (bytes / (1024 * 1024)).toFixed(2) + ' MB';

    const formatUptime = (seconds) => {
      const days = Math.floor(seconds / (24 * 3600));
      const hours = Math.floor((seconds % (24 * 3600)) / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      return `${days}d ${hours}h ${minutes}m`;
    };

    return NextResponse.json({
      node_version: process.version,
      uptime: formatUptime(process.uptime()),
      memory_used: formatMemory(process.memoryUsage().rss),
      db_version: dbVersion.rows[0].version.split(',')[0],
      total_users: parseInt(userCount.rows[0].count),
      total_numbers: parseInt(numberCount.rows[0].count),
      os_platform: os.platform(),
      os_release: os.release(),
    });
  } catch (err) {
    console.error('System info error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
