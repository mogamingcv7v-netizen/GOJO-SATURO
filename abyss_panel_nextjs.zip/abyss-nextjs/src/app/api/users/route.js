import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';
import { validateCreateUser } from '@/lib/validation';

// GET /api/users
export const GET = withAuth(async (request) => {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const per = parseInt(searchParams.get('per') || '20');
    const q = searchParams.get('q');
    const offset = (page - 1) * per;

    let query = 'SELECT id, username, name, email, country, role, active, last_login, created_at FROM users WHERE 1=1';
    let countQuery = 'SELECT COUNT(*) FROM users WHERE 1=1';
    let params = [];

    if (q) {
      query += ' AND (username ILIKE $1 OR name ILIKE $1 OR email ILIKE $1)';
      countQuery += ' AND (username ILIKE $1 OR name ILIKE $1 OR email ILIKE $1)';
      params.push(`%${q}%`);
    }

    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(per, offset);

    const result = await db.query(query, params);
    const countResult = await db.query(countQuery, params.slice(0, params.length - 2));

    return NextResponse.json({
      data: result.rows,
      total: parseInt(countResult.rows[0].count),
      page,
      per,
    });
  } catch (err) {
    console.error('Get users error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);

// POST /api/users
export const POST = withAuth(async (request) => {
  try {
    const body = await request.json().catch(() => ({}));
    const validationError = validateCreateUser(body);
    if (validationError) return NextResponse.json(validationError, { status: 400 });

    const { username, password, name, email, country, role } = body;
    const hashedPassword = await bcrypt.hash(password, 12);

    const result = await db.query(
      'INSERT INTO users (username, password, name, email, country, role) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id, username, name, email, country, role',
      [username.trim(), hashedPassword, name || null, email || null, country || null, role || 'user']
    );

    return NextResponse.json(result.rows[0], { status: 201 });
  } catch (err) {
    if (err.code === '23505') {
      return NextResponse.json({ error: 'Username already taken' }, { status: 400 });
    }
    console.error('Create user error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
