import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// PATCH /api/users/:id/toggle
export const PATCH = withAuth(async (request, { params }) => {
  try {
    const { id } = params;
    const result = await db.query(
      'UPDATE users SET active = NOT active WHERE id = $1 RETURNING active',
      [id]
    );
    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }
    return NextResponse.json({ active: result.rows[0].active });
  } catch (err) {
    console.error('Toggle user error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
