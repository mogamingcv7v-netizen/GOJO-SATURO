import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/users/:id
export const GET = withAuth(async (request, { params }) => {
  try {
    const { id } = params;
    const result = await db.query(
      'SELECT id, username, name, email, country, role, active, last_login, created_at FROM users WHERE id = $1',
      [id]
    );
    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }
    return NextResponse.json(result.rows[0]);
  } catch (err) {
    console.error('Get user error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);

// PUT /api/users/:id
export const PUT = withAuth(async (request, { params }) => {
  try {
    const { id } = params;
    const { name, email, country, role } = await request.json().catch(() => ({}));

    if (role && !['superadmin', 'dev', 'user'].includes(role)) {
      return NextResponse.json({ error: 'Invalid role' }, { status: 400 });
    }

    const result = await db.query(
      'UPDATE users SET name = $1, email = $2, country = $3, role = $4 WHERE id = $5 RETURNING id, username, name, email, country, role',
      [name || null, email || null, country || null, role, id]
    );
    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }
    return NextResponse.json(result.rows[0]);
  } catch (err) {
    console.error('Update user error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);

// DELETE /api/users/:id
export const DELETE = withAuth(async (request, { params }) => {
  const client = await db.pool.connect();
  try {
    const { id } = params;
    await client.query('BEGIN');

    // Get assigned numbers to return to stock
    const numbersResult = await client.query(
      'SELECT range_id, COUNT(*) as count FROM numbers WHERE assigned_to = $1 GROUP BY range_id',
      [id]
    );

    for (const row of numbersResult.rows) {
      await client.query(
        'UPDATE ranges SET assigned_count = assigned_count - $1, stock_count = stock_count + $1 WHERE id = $2',
        [row.count, row.range_id]
      );
    }

    await client.query('UPDATE numbers SET assigned_to = NULL, assigned_date = NULL WHERE assigned_to = $1', [id]);
    await client.query('DELETE FROM users WHERE id = $1', [id]);

    await client.query('COMMIT');
    return NextResponse.json({ message: 'User deleted and numbers returned to stock' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Delete user error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  } finally {
    client.release();
  }
}, ['superadmin', 'dev']);
