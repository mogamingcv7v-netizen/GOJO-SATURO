import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/users/performance
export const GET = withAuth(async () => {
  try {
    const result = await db.query(`
      SELECT
        u.id, u.username, u.name,
        COUNT(DISTINCT n.id) as numbers_count,
        COALESCE(SUM(t.sms), 0) as sms_count,
        COALESCE(SUM(t.payout), 0) as total_payout
      FROM users u
      LEFT JOIN numbers n ON u.id = n.assigned_to
      LEFT JOIN traffic t ON u.id = t.user_id
      WHERE u.role = 'user'
      GROUP BY u.id, u.username, u.name
      ORDER BY sms_count DESC
    `);

    return NextResponse.json({ data: result.rows });
  } catch (err) {
    console.error('User performance error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
