import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/ranges
export const GET = withAuth(async (request) => {
  try {
    const { searchParams } = new URL(request.url);
    const q = searchParams.get('q');

    let query = 'SELECT * FROM ranges';
    let params = [];

    if (q) {
      query += ' WHERE name ILIKE $1 OR country ILIKE $1 OR prefix ILIKE $1';
      params.push(`%${q}%`);
    }

    query += ' ORDER BY created_at DESC';
    const result = await db.query(query, params);
    return NextResponse.json({ data: result.rows });
  } catch (err) {
    console.error('Get ranges error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
