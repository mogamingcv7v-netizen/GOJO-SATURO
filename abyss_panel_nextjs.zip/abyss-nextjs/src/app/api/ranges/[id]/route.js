import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/ranges/:id
export const GET = withAuth(async (request, { params }) => {
  try {
    const { id } = params;
    const result = await db.query('SELECT * FROM ranges WHERE id = $1', [id]);
    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Range not found' }, { status: 404 });
    }
    return NextResponse.json(result.rows[0]);
  } catch (err) {
    console.error('Get range error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);

// PUT /api/ranges/:id
export const PUT = withAuth(async (request, { params }) => {
  try {
    const { id } = params;
    const { name, default_payout, default_payterm } = await request.json().catch(() => ({}));

    const result = await db.query(
      'UPDATE ranges SET name = $1, default_payout = $2, default_payterm = $3 WHERE id = $4 RETURNING *',
      [name || null, default_payout || 0, default_payterm || 30, id]
    );

    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Range not found' }, { status: 404 });
    }

    return NextResponse.json(result.rows[0]);
  } catch (err) {
    console.error('Update range error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);

// DELETE /api/ranges/:id
export const DELETE = withAuth(async (request, { params }) => {
  try {
    const { id } = params;
    const result = await db.query('DELETE FROM ranges WHERE id = $1 RETURNING id', [id]);
    if (result.rows.length === 0) {
      return NextResponse.json({ error: 'Range not found' }, { status: 404 });
    }
    return NextResponse.json({ message: 'Range and associated numbers deleted' });
  } catch (err) {
    console.error('Delete range error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
