import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';
import { getAuthUser } from '@/lib/auth';

// POST /api/ranges/upload
// Next.js 14 App Router handles multipart via request.formData()
export async function POST(request) {
  const { user, error, status } = await getAuthUser(request);
  if (error) return NextResponse.json({ error }, { status });
  if (!['superadmin', 'dev'].includes(user.role)) {
    return NextResponse.json({ error: 'Insufficient permissions' }, { status: 403 });
  }

  try {
    const formData = await request.formData();
    const file = formData.get('file');
    const name = formData.get('name') || null;
    const default_payout = parseFloat(formData.get('default_payout') || '0') || 0;
    const default_payterm = parseInt(formData.get('default_payterm') || '30') || 30;

    if (!file || typeof file === 'string') {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
    }

    // Only allow .txt files
    if (!file.name.toLowerCase().endsWith('.txt')) {
      return NextResponse.json({ error: 'Only .txt files are allowed' }, { status: 400 });
    }

    // 5MB limit
    if (file.size > 5 * 1024 * 1024) {
      return NextResponse.json({ error: 'File too large (max 5MB)' }, { status: 400 });
    }

    const content = await file.text();
    const numbers = content.split('\n').map(n => n.trim()).filter(n => n.length > 0);

    if (numbers.length === 0) {
      return NextResponse.json({ error: 'File is empty or invalid' }, { status: 400 });
    }

    // Auto-detect country/prefix
    const firstNum = numbers[0];
    let prefix = '';
    let country = 'Unknown';

    if (firstNum.startsWith('+')) {
      prefix = firstNum.substring(0, 4);
      country = 'Auto-detected';
    } else if (firstNum.startsWith('44')) {
      prefix = '44';
      country = 'United Kingdom';
    } else if (firstNum.startsWith('1')) {
      prefix = '1';
      country = 'USA/Canada';
    }

    const rangeName = name || `Range-${new Date().toISOString().split('T')[0]}-${Math.floor(Math.random() * 1000)}`;

    const rangeResult = await db.query(
      'INSERT INTO ranges (name, country, prefix, default_payout, default_payterm, total_count, stock_count) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
      [rangeName, country, prefix, default_payout, default_payterm, numbers.length, numbers.length]
    );

    const range = rangeResult.rows[0];

    // Bulk insert numbers
    for (const num of numbers) {
      await db.query(
        'INSERT INTO numbers (number, range_id, country, payout, payterm) VALUES ($1, $2, $3, $4, $5) ON CONFLICT (number) DO NOTHING',
        [num, range.id, country, range.default_payout, range.default_payterm]
      );
    }

    return NextResponse.json({
      message: 'Range uploaded and imported successfully',
      range,
      count: numbers.length,
    });
  } catch (err) {
    console.error('Upload range error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
