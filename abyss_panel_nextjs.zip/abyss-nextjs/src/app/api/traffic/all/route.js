import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// DELETE /api/traffic/all
export const DELETE = withAuth(async () => {
  try {
    await db.query('TRUNCATE TABLE traffic');
    await db.query('UPDATE numbers SET sms_today = 0, sms_total = 0');
    return NextResponse.json({ message: 'All traffic cleared' });
  } catch (err) {
    console.error('Clear traffic error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin']);
