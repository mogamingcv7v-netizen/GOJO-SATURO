import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// DELETE /api/traffic/:id
export const DELETE = withAuth(async (request, { params }) => {
  try {
    const { id } = params;
    await db.query('DELETE FROM traffic WHERE id = $1', [id]);
    return NextResponse.json({ message: 'Record deleted' });
  } catch (err) {
    console.error('Delete traffic error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
