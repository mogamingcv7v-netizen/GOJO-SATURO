import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';
import { validateTrafficLog } from '@/lib/validation';

// POST /api/traffic
export const POST = withAuth(async (request) => {
  const client = await db.pool.connect();
  try {
    const body = await request.json().catch(() => ({}));
    const validationError = validateTrafficLog(body);
    if (validationError) return NextResponse.json(validationError, { status: 400 });

    const { number_id, number, cli, sms = 1, currency = 'USD', payout } = body;
    const ip =
      request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      request.headers.get('x-real-ip') ||
      '127.0.0.1';

    await client.query('BEGIN');

    const numResult = await client.query(
      'SELECT range_id, assigned_to, payout FROM numbers WHERE id = $1',
      [number_id]
    );

    if (numResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return NextResponse.json({ error: 'Number not found' }, { status: 404 });
    }

    const num = numResult.rows[0];
    const finalPayout = payout !== undefined ? payout : num.payout;

    const trafficResult = await client.query(
      'INSERT INTO traffic (number_id, number, range_id, user_id, cli, sms, payout, currency, ip) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *',
      [number_id, number, num.range_id, num.assigned_to, cli, sms, finalPayout, currency, ip]
    );

    await client.query(
      'UPDATE numbers SET sms_today = sms_today + $1, sms_total = sms_total + $1, last_sms_at = CURRENT_TIMESTAMP WHERE id = $2',
      [sms, number_id]
    );

    await client.query('COMMIT');
    return NextResponse.json(trafficResult.rows[0], { status: 201 });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Traffic logging error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  } finally {
    client.release();
  }
});

// GET /api/traffic
export const GET = withAuth(async (request) => {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const per = parseInt(searchParams.get('per') || '20');
    const q = searchParams.get('q');
    const from = searchParams.get('from');
    const to = searchParams.get('to');
    const user_id = searchParams.get('user_id');
    const offset = (page - 1) * per;

    let query = `
      SELECT t.*, r.name as range_name, u.username
      FROM traffic t
      LEFT JOIN ranges r ON t.range_id = r.id
      LEFT JOIN users u ON t.user_id = u.id
      WHERE 1=1
    `;
    let countQuery = 'SELECT COUNT(*) FROM traffic t WHERE 1=1';
    let params = [];
    let pIdx = 1;

    if (request.authUser.role === 'user') {
      query += ` AND t.user_id = $${pIdx}`;
      countQuery += ` AND t.user_id = $${pIdx}`;
      params.push(request.authUser.id);
      pIdx++;
    } else if (user_id) {
      query += ` AND t.user_id = $${pIdx}`;
      countQuery += ` AND t.user_id = $${pIdx}`;
      params.push(user_id);
      pIdx++;
    }

    if (q) {
      query += ` AND (t.number ILIKE $${pIdx} OR t.cli ILIKE $${pIdx})`;
      countQuery += ` AND (t.number ILIKE $${pIdx} OR t.cli ILIKE $${pIdx})`;
      params.push(`%${q}%`);
      pIdx++;
    }

    if (from) {
      query += ` AND t.recorded_at >= $${pIdx}`;
      countQuery += ` AND t.recorded_at >= $${pIdx}`;
      params.push(from);
      pIdx++;
    }

    if (to) {
      query += ` AND t.recorded_at <= $${pIdx}`;
      countQuery += ` AND t.recorded_at <= $${pIdx}`;
      params.push(to);
      pIdx++;
    }

    query += ` ORDER BY t.recorded_at DESC LIMIT $${pIdx} OFFSET $${pIdx + 1}`;
    params.push(per, offset);

    const result = await db.query(query, params);
    const countResult = await db.query(countQuery, params.slice(0, pIdx - 1));

    return NextResponse.json({
      data: result.rows,
      total: parseInt(countResult.rows[0].count),
      page,
      per,
    });
  } catch (err) {
    console.error('Get traffic error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
});
