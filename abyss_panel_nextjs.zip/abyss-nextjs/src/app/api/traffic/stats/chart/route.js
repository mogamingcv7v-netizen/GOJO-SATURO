import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/traffic/stats/chart
export const GET = withAuth(async (request) => {
  try {
    const { searchParams } = new URL(request.url);
    const days = parseInt(searchParams.get('days') || '30');
    const userId = request.authUser.id;
    const isAdmin = request.authUser.role !== 'user';
    const userFilter = isAdmin ? '' : 'AND user_id = $2';
    const params = isAdmin ? [days] : [days, userId];

    const result = await db.query(`
      SELECT
        TO_CHAR(recorded_at, 'YYYY-MM-DD') as date,
        SUM(sms) as count
      FROM traffic
      WHERE recorded_at >= CURRENT_DATE - INTERVAL '1 day' * $1
      ${userFilter}
      GROUP BY date
      ORDER BY date ASC
    `, params);

    const labels = [];
    const values = [];

    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const monthDay = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      labels.push(monthDay);
      const row = result.rows.find(r => r.date === dateStr);
      values.push(row ? parseInt(row.count) : 0);
    }

    return NextResponse.json({ labels, values });
  } catch (err) {
    console.error('Chart data error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
});
