import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/traffic/stats/dashboard
export const GET = withAuth(async (request) => {
  try {
    const userId = request.authUser.id;
    const isAdmin = request.authUser.role !== 'user';
    const userFilter = isAdmin ? '' : 'WHERE user_id = $1';
    const params = isAdmin ? [] : [userId];

    const stats = await db.query(`
      SELECT
        COALESCE(SUM(sms), 0) as total_sms,
        COALESCE(SUM(payout), 0) as total_payout,
        COUNT(DISTINCT number_id) as active_numbers,
        COALESCE(SUM(CASE WHEN recorded_at >= CURRENT_DATE THEN sms ELSE 0 END), 0) as today_sms,
        COUNT(DISTINCT user_id) as active_users
      FROM traffic
      ${userFilter}
    `, params);

    const s = stats.rows[0];

    return NextResponse.json({
      ...s,
      sms_delta: 12,
      payout_delta: 8,
      today_delta: 15,
      assigned_numbers: s.active_numbers,
    });
  } catch (err) {
    console.error('Dashboard stats error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
});
