import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/traffic/stats/numbers
export const GET = withAuth(async (request) => {
  try {
    const userId = request.authUser.id;
    const isAdmin = request.authUser.role !== 'user';
    const userFilter = isAdmin ? '' : 'WHERE t.user_id = $1';
    const params = isAdmin ? [] : [userId];

    const result = await db.query(`
      SELECT
        t.number,
        r.name as range_name,
        SUM(t.sms) as sms_count
      FROM traffic t
      LEFT JOIN ranges r ON t.range_id = r.id
      ${userFilter}
      GROUP BY t.number, r.name
      ORDER BY sms_count DESC
      LIMIT 10
    `, params);

    return NextResponse.json({ data: result.rows });
  } catch (err) {
    console.error('Top numbers error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
});
