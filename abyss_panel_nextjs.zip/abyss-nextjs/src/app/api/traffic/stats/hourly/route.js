import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/traffic/stats/hourly
export const GET = withAuth(async (request) => {
  try {
    const userId = request.authUser.id;
    const isAdmin = request.authUser.role !== 'user';
    const userFilter = isAdmin ? '' : 'WHERE user_id = $1';
    const params = isAdmin ? [] : [userId];

    const result = await db.query(`
      SELECT
        EXTRACT(DOW FROM recorded_at) as day,
        EXTRACT(HOUR FROM recorded_at) as hour,
        SUM(sms) as count
      FROM traffic
      ${userFilter}
      GROUP BY day, hour
    `, params);

    const data = Array.from({ length: 7 }, () => Array(24).fill(0));
    result.rows.forEach(r => {
      data[parseInt(r.day)][parseInt(r.hour)] = parseInt(r.count);
    });

    return NextResponse.json({ data });
  } catch (err) {
    console.error('Heatmap error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
});
