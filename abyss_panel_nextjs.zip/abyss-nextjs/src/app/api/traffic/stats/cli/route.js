import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/traffic/stats/cli
export const GET = withAuth(async (request) => {
  try {
    const userId = request.authUser.id;
    const isAdmin = request.authUser.role !== 'user';
    const userFilter = isAdmin ? '' : 'WHERE user_id = $1';
    const params = isAdmin ? [] : [userId];

    const result = await db.query(`
      SELECT cli, SUM(sms) as count
      FROM traffic
      ${userFilter}
      GROUP BY cli
      ORDER BY count DESC
      LIMIT 10
    `, params);

    return NextResponse.json({ data: result.rows });
  } catch (err) {
    console.error('Top CLIs error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
