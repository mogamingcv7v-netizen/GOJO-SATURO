import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/numbers/alloc-log
export const GET = withAuth(async () => {
  try {
    const result = await db.query('SELECT * FROM allocation_log ORDER BY created_at DESC LIMIT 100');
    return NextResponse.json({ data: result.rows });
  } catch (err) {
    console.error('Get allocation log error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}, ['superadmin', 'dev']);
