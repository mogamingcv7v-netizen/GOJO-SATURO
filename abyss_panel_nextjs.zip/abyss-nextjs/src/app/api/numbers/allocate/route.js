import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// POST /api/numbers/allocate
export const POST = withAuth(async (request) => {
  const client = await db.pool.connect();
  try {
    const { range_id, user_id, qty, payout } = await request.json().catch(() => ({}));

    if (!range_id || !user_id || !qty) {
      return NextResponse.json({ error: 'Range ID, user ID, and quantity are required' }, { status: 400 });
    }

    await client.query('BEGIN');

    const stockResult = await client.query(
      'SELECT id, name FROM ranges WHERE id = $1 AND stock_count >= $2',
      [range_id, qty]
    );
    if (stockResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return NextResponse.json({ error: 'Insufficient stock in range' }, { status: 400 });
    }

    const range = stockResult.rows[0];

    const numbersResult = await client.query(
      'SELECT id FROM numbers WHERE range_id = $1 AND assigned_to IS NULL LIMIT $2',
      [range_id, qty]
    );

    const numIds = numbersResult.rows.map(n => n.id);
    if (numIds.length < qty) {
      await client.query('ROLLBACK');
      return NextResponse.json({ error: 'Failed to find enough available numbers' }, { status: 400 });
    }

    const payoutValue = payout || null;
    await client.query(
      `UPDATE numbers
       SET assigned_to = $1, assigned_date = CURRENT_TIMESTAMP, payout = COALESCE($2, payout)
       WHERE id = ANY($3)`,
      [user_id, payoutValue, numIds]
    );

    await client.query(
      'UPDATE ranges SET assigned_count = assigned_count + $1, stock_count = stock_count - $1 WHERE id = $2',
      [numIds.length, range_id]
    );

    const userResult = await client.query('SELECT username FROM users WHERE id = $1', [user_id]);
    const username = userResult.rows[0]?.username;

    await client.query(
      'INSERT INTO allocation_log (user_id, username, range_id, range_name, qty) VALUES ($1, $2, $3, $4, $5)',
      [user_id, username, range_id, range.name, numIds.length]
    );

    await client.query('COMMIT');
    return NextResponse.json({ message: 'Numbers allocated successfully', allocated: numIds.length });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Allocation error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  } finally {
    client.release();
  }
}, ['superadmin', 'dev']);
