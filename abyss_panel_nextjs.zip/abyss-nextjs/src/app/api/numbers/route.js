import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/numbers
export const GET = withAuth(async (request) => {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const per = parseInt(searchParams.get('per') || '20');
    const q = searchParams.get('q');
    const mine = searchParams.get('mine');
    const range_id = searchParams.get('range_id');
    const status = searchParams.get('status');
    const active = searchParams.get('active');
    const offset = (page - 1) * per;

    let query = `
      SELECT n.*, r.name as range_name, u.username
      FROM numbers n
      LEFT JOIN ranges r ON n.range_id = r.id
      LEFT JOIN users u ON n.assigned_to = u.id
      WHERE 1=1
    `;
    let countQuery = 'SELECT COUNT(*) FROM numbers n WHERE 1=1';
    let params = [];
    let pIdx = 1;

    if (q) {
      query += ` AND (n.number ILIKE $${pIdx} OR u.username ILIKE $${pIdx})`;
      countQuery += ` AND (n.number ILIKE $${pIdx})`;
      params.push(`%${q}%`);
      pIdx++;
    }

    if (mine === '1') {
      query += ` AND n.assigned_to = $${pIdx}`;
      countQuery += ` AND n.assigned_to = $${pIdx}`;
      params.push(request.authUser.id);
      pIdx++;
    }

    if (range_id) {
      query += ` AND n.range_id = $${pIdx}`;
      countQuery += ` AND n.range_id = $${pIdx}`;
      params.push(range_id);
      pIdx++;
    }

    if (status === 'assigned') {
      query += ' AND n.assigned_to IS NOT NULL';
      countQuery += ' AND n.assigned_to IS NOT NULL';
    } else if (status === 'stock') {
      query += ' AND n.assigned_to IS NULL';
      countQuery += ' AND n.assigned_to IS NULL';
    }

    if (active === '1') {
      query += ' AND n.active = true';
      countQuery += ' AND n.active = true';
    }

    query += ` ORDER BY n.created_at DESC LIMIT $${pIdx} OFFSET $${pIdx + 1}`;
    params.push(per, offset);

    const result = await db.query(query, params);
    const countResult = await db.query(countQuery, params.slice(0, pIdx - 1));

    return NextResponse.json({
      data: result.rows,
      total: parseInt(countResult.rows[0].count),
      page,
      per,
    });
  } catch (err) {
    console.error('Get numbers error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
});
