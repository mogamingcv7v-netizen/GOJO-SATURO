import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// PATCH /api/numbers/:id/unassign
export const PATCH = withAuth(async (request, { params }) => {
  const client = await db.pool.connect();
  try {
    const { id } = params;
    await client.query('BEGIN');

    const result = await client.query(
      'SELECT range_id, assigned_to FROM numbers WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return NextResponse.json({ error: 'Number not found' }, { status: 404 });
    }

    const { range_id, assigned_to } = result.rows[0];
    if (!assigned_to) {
      await client.query('ROLLBACK');
      return NextResponse.json({ error: 'Number is already in stock' }, { status: 400 });
    }

    await client.query(
      'UPDATE numbers SET assigned_to = NULL, assigned_date = NULL WHERE id = $1',
      [id]
    );

    await client.query(
      'UPDATE ranges SET assigned_count = assigned_count - 1, stock_count = stock_count + 1 WHERE id = $1',
      [range_id]
    );

    await client.query('COMMIT');
    return NextResponse.json({ message: 'Number returned to stock' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Unassign error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  } finally {
    client.release();
  }
}, ['superadmin', 'dev']);
