import { NextResponse } from 'next/server';
import { withAuth } from '@/lib/auth';
import { db } from '@/lib/db';

// DELETE /api/numbers/:id
export const DELETE = withAuth(async (request, { params }) => {
  const client = await db.pool.connect();
  try {
    const { id } = params;
    await client.query('BEGIN');

    const result = await client.query(
      'SELECT range_id, assigned_to FROM numbers WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      await client.query('ROLLBACK');
      return NextResponse.json({ error: 'Number not found' }, { status: 404 });
    }

    const { range_id, assigned_to } = result.rows[0];
    await client.query('DELETE FROM numbers WHERE id = $1', [id]);

    if (assigned_to) {
      await client.query(
        'UPDATE ranges SET total_count = total_count - 1, assigned_count = assigned_count - 1 WHERE id = $1',
        [range_id]
      );
    } else {
      await client.query(
        'UPDATE ranges SET total_count = total_count - 1, stock_count = stock_count - 1 WHERE id = $1',
        [range_id]
      );
    }

    await client.query('COMMIT');
    return NextResponse.json({ message: 'Number deleted' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Delete number error:', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  } finally {
    client.release();
  }
}, ['superadmin', 'dev']);
