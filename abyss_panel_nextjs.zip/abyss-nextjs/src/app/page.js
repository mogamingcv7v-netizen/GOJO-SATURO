import { NextResponse } from 'next/server';

export default function Home() {
  return (
    <main style={{ fontFamily: 'monospace', padding: '2rem', background: '#0a0a0a', color: '#00ff88', minHeight: '100vh' }}>
      <h1>⚡ ABYSS PANEL API</h1>
      <p>Enterprise SMS Management System — Next.js Backend</p>
      <hr style={{ borderColor: '#00ff8844' }} />
      <h2>Available Endpoints</h2>
      <pre>{`
GET    /api/health

POST   /api/auth/login
POST   /api/auth/register
GET    /api/auth/me
PUT    /api/auth/profile
PUT    /api/auth/password

GET    /api/users
POST   /api/users
GET    /api/users/performance
GET    /api/users/:id
PUT    /api/users/:id
PATCH  /api/users/:id/toggle
DELETE /api/users/:id

GET    /api/ranges
POST   /api/ranges/upload
GET    /api/ranges/:id
PUT    /api/ranges/:id
DELETE /api/ranges/:id

GET    /api/numbers
POST   /api/numbers/allocate
GET    /api/numbers/alloc-log
PATCH  /api/numbers/:id/unassign
DELETE /api/numbers/:id

POST   /api/traffic
GET    /api/traffic
GET    /api/traffic/stats/dashboard
GET    /api/traffic/stats/chart
GET    /api/traffic/stats/hourly
GET    /api/traffic/stats/numbers
GET    /api/traffic/stats/cli
DELETE /api/traffic/:id
DELETE /api/traffic/all

GET    /api/admin/dev-codes
POST   /api/admin/dev-codes
DELETE /api/admin/dev-codes/:id
GET    /api/admin/system-info

GET    /api/targets
GET    /api/targets/:user_id
PUT    /api/targets/:user_id/:type
      `}</pre>
    </main>
  );
}
