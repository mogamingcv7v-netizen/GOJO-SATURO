export const metadata = {
  title: 'ABYSS PANEL API',
  description: 'Enterprise SMS Management System',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
