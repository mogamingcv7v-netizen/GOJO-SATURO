/** @type {import('next').NextConfig} */
const nextConfig = {
  // Allow larger body for file uploads
  api: {
    bodyParser: false,
  },
};

module.exports = nextConfig;
