# ABYSS PANEL — Next.js Backend

Enterprise SMS Management System, converted to **Next.js 14 App Router**.

---

## 🗂️ Project Structure

```
src/
  app/
    api/
      health/
      auth/         login, register, me, profile, password
      users/        CRUD + performance + toggle
      ranges/       CRUD + upload
      numbers/      list, allocate, alloc-log, unassign, delete
      traffic/      log, list, stats (dashboard, chart, hourly, numbers, cli), delete, clear
      admin/        dev-codes, system-info
      targets/      get, update
  lib/
    db.js           PostgreSQL pool (singleton)
    auth.js         JWT helpers + withAuth() HOF
    validation.js   Input validators
    rateLimit.js    In-memory rate limiter
migrations/
  001_initial_schema.sql
  migrate.js
  seed.js
```

---

## 🚀 Pterodactyl / LumenWeb Deployment

### 1. Upload & Install
```bash
# In your Pterodactyl console / startup:
npm install
```

### 2. Configure Environment
Copy `.env.example` to `.env.local` and fill in your values:
```bash
cp .env.example .env.local
```

Required variables:
```
DB_HOST=your_postgres_host
DB_PORT=5432
DB_NAME=abyss_panel
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_SSL=false
JWT_SECRET=your_super_secret_key_min_32_chars_long
JWT_EXPIRES_IN=24h
```

### 3. Run Migrations
```bash
node migrations/migrate.js
node migrations/seed.js
```

### 4. Build & Start
```bash
npm run build
npm start
```

For **LumenWeb egg** (lumenweb/modified Node egg on Pterodactyl), set:
- **Startup command**: `npm run build && npm start`
- **Node version**: 18+ recommended
- **Port**: whatever Pterodactyl assigns (Next.js reads `PORT` env automatically)

> ⚠️ Make sure `PORT` env variable is set by the egg — Next.js will listen on it automatically.

---

## 🔑 Authentication

All protected routes require:
```
Authorization: Bearer <token>
```

Roles: `superadmin` > `dev` > `user`

---

## 📡 API Endpoints

| Method | Endpoint | Role |
|--------|----------|------|
| POST | /api/auth/login | public |
| POST | /api/auth/register | public |
| GET | /api/auth/me | any |
| PUT | /api/auth/profile | any |
| PUT | /api/auth/password | any |
| GET | /api/users | superadmin, dev |
| POST | /api/users | superadmin, dev |
| GET | /api/users/performance | superadmin, dev |
| GET/PUT/DELETE | /api/users/:id | superadmin, dev |
| PATCH | /api/users/:id/toggle | superadmin, dev |
| GET | /api/ranges | superadmin, dev |
| POST | /api/ranges/upload | superadmin, dev |
| GET/PUT/DELETE | /api/ranges/:id | superadmin, dev |
| GET | /api/numbers | any |
| POST | /api/numbers/allocate | superadmin, dev |
| GET | /api/numbers/alloc-log | superadmin, dev |
| PATCH | /api/numbers/:id/unassign | superadmin, dev |
| DELETE | /api/numbers/:id | superadmin, dev |
| POST | /api/traffic | any |
| GET | /api/traffic | any (filtered by role) |
| GET | /api/traffic/stats/dashboard | any |
| GET | /api/traffic/stats/chart | any |
| GET | /api/traffic/stats/hourly | any |
| GET | /api/traffic/stats/numbers | any |
| GET | /api/traffic/stats/cli | superadmin, dev |
| DELETE | /api/traffic/:id | superadmin, dev |
| DELETE | /api/traffic/all | superadmin |
| GET/POST | /api/admin/dev-codes | superadmin |
| DELETE | /api/admin/dev-codes/:id | superadmin |
| GET | /api/admin/system-info | superadmin, dev |
| GET | /api/targets | superadmin, dev |
| GET | /api/targets/:user_id | superadmin, dev |
| PUT | /api/targets/:user_id/:type | superadmin, dev |

---

## 📦 Default Credentials (after seed)
- **Username**: admin
- **Password**: admin123

> Change immediately after first login!
